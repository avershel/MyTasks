//
//  ViewController.swift
//  MyTasksForClass
//
//  Created by Austin on 3/31/17.
//  Copyright © 2017 Austin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tf: UITextField!
    @IBOutlet weak var gobutton: UIButton!
    @IBOutlet weak var textfield: UILabel!

    @IBOutlet weak var letsgobutton: UIButton!
    var yourArray = [String]()

    var finalstring = ""
    var count = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        textfield.text = ""
        letsgobutton.isHidden = true

    }
    
    
    
    
    @IBAction func letsgopressed(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
            
            let yourNextViewController = (segue.destination as! ViewController2)
            yourNextViewController.count = 3
            yourNextViewController.finalstring = finalstring
            yourNextViewController.yourArray = yourArray

        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func gopressed(_ sender: Any) {
        finalstring = ""
        if(tf.text != ""){
            let trimmedString = tf.text!.trimmingCharacters(in: .whitespaces)
            let myURLString = "http://www.prettygoodsports.com/api.php?" + trimmedString.lowercased()
            guard let myURL = URL(string: myURLString) else {
                print("Error: \(myURLString) doesn't seem to be a valid URL")
                return
            }
            
            do {
                var myHTMLString = try String(contentsOf: myURL, encoding: .ascii)
                myHTMLString.remove(at: myHTMLString.index(before: myHTMLString.endIndex))
                myHTMLString.remove(at: myHTMLString.startIndex)
                let holder = myHTMLString.components(separatedBy: "},")
                if(holder.count > 1){
                for var i in (0..<holder.count){
                    let endIndex = holder[i].index(holder[i].endIndex, offsetBy: -1)
                    var truncated = holder[i].substring(to: endIndex)
                    var x = truncated.components(separatedBy: "\"")
                    
                    if i == holder.count - 1 {
                        if x[x.count - 2].range(of:"##") != nil{
                            var y = x[x.count - 2].components(separatedBy: "##")
                            for var ii in (0..<y.count){
                                finalstring += y[ii]
                                yourArray.append(y[ii])
                                finalstring += "\n"
                                count += 1
                            }
                        }
                        else{
                            finalstring += x[x.count - 2]
                            yourArray.append(x[x.count - 2])

                            finalstring += "\n"
                            count += 1

                        }
                    }else{
                        //Starts here
                        
                        if x.last!.range(of:"##") != nil{
                            var y = x.last!.components(separatedBy: "##")
                            for var ii in (0..<y.count){
                                finalstring += y[ii]
                                yourArray.append(y[ii])

                                finalstring += "\n"
                                count += 1

                            }
                        }
                        else{
                            finalstring += x.last!
                            yourArray.append(x.last!)

                            finalstring += "\n"
                            count += 1

                        }
                        
                        //ends


                    }

                }
                }else{
                    textfield.text = "Need atleast 2 tasks!"

                }


                textfield.text = "\(count) Tasks Found!"
                if(count > 0){
                    letsgobutton.isHidden = false

                }
            } catch let error {
                print("Error: \(error)")
            }
        }
    }

}

