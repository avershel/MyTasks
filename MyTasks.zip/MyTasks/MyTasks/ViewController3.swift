//
//  ViewController3.swift
//  Tasks
//
//  Created by Austin on 4/7/17.
//  Copyright © 2017 Austin. All rights reserved.
//

import Foundation
//
//  ViewController2.swift
//  Tasks
//
//  Created by Austin on 4/7/17.
//  Copyright © 2017 Austin. All rights reserved.
//

import Foundation
import UIKit

class ViewController3: UIViewController {
      var finalstring = ""
var rightindex = 0
    var holderindex = 0
    @IBOutlet weak var tasklabel: UILabel!
    @IBOutlet weak var outoflabel: UILabel!
    @IBOutlet weak var nobutton: UIButton!
    
    @IBOutlet weak var yesbutton: UIButton!
    @IBOutlet weak var didyou: UILabel!
    @IBOutlet weak var finishedbutton: UIButton!
var yourArray = [String]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        outoflabel.text = "\(rightindex)/\(yourArray.count)"
        tasklabel.text = "\(yourArray[holderindex])?"
        finishedbutton.isHidden = true

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func yespressed(_ sender: Any) {
        


        if (holderindex < yourArray.count - 1) {
            
            rightindex = rightindex + 1
            outoflabel.text = "\(rightindex)/\(yourArray.count)"
        holderindex = holderindex + 1
        tasklabel.text = "\(yourArray[holderindex])?"
        }else{
            
            finishedbutton.isHidden = false
            didyou.text = "Nice Job!"
            yesbutton.isHidden = true
            nobutton.isHidden = true
            tasklabel.isHidden = true
        }

    }

    @IBAction func nopressed(_ sender: Any) {
        if (holderindex < yourArray.count - 1) {
            
            
            holderindex = holderindex + 1
        tasklabel.text = "\(yourArray[holderindex])?"
        }else{
            finishedbutton.isHidden = false
            tasklabel.text = "Nice Job!"
            didyou.isHidden = true
            yesbutton.isHidden = true
            nobutton.isHidden = true
        }

        
    }
}
