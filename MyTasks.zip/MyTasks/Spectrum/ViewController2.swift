//
//  ViewController2.swift
//  Tasks
//
//  Created by Austin on 4/7/17.
//  Copyright © 2017 Austin. All rights reserved.
//

import Foundation
import UIKit

class ViewController2: UIViewController {
    
    @IBOutlet weak var timerlabel: UILabel!

    @IBOutlet weak var tasklabel: UILabel!
    
    @IBOutlet weak var breakbutton: UIButton!
    var finalstring = ""
    var count = 0
    var timer = Timer()
    var yourArray = [String]()
    var seconds = "00"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        timerlabel.text = "\(count):\(seconds)"
        tasklabel.text = finalstring
        timer = Timer.scheduledTimer(timeInterval: 0.9, target: self, selector: #selector(ViewController2.update), userInfo: nil, repeats: true)

    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        let yourNextViewController = (segue.destination as! ViewController3)
        yourNextViewController.finalstring = finalstring
        yourNextViewController.yourArray = yourArray
        
        
    }
    
    func update() {
        

        if(Int(seconds) == 0){
            count = count - 1
            seconds = "59"
        }else{
            
            seconds = String(Int(seconds)! - 1)
            
        }
        if (Int(seconds)! < 10) {
            seconds = "0\(seconds)"
        }
            timerlabel.text = "\(count):\(seconds)"
        
    }

    
    @IBAction func needabreak(_ sender: Any) {
        if(timer.isValid){
            timer.invalidate()

        }else{
                    timer = Timer.scheduledTimer(timeInterval: 0.9, target: self, selector: #selector(ViewController2.update), userInfo: nil, repeats: true)
        }
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
}

}
